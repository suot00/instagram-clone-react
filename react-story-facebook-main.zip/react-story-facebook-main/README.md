# React Story Facebook

## Installation

Navigate to **chrome://extensions/** and click the "Load unpacked extension..." button. Navigate to and select this
directory. You should then see an "Improved new tab page" extension and see the app when you open a new tab.

## Screenshot

![](https://i.imgur.com/5QIHXp0.png)

## Summary

If you like my project, give it a star ✨ and share it with your friends